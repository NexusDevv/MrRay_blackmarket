# Credits

## Development Team

**Nexus-development** by **MrRay**

---

## Resource Information

- **Resource Name**: MrRay Blackmarket
- **Version**: 1.0.0
- **Framework**: QBox
- **Author**: MrRay
- **Organization**: Nexus-development

---

## Features

- Advanced Multi-Functional Black Market NUI
- Ox_Inventory Integration with Authentic GTA V Weapon Images
- Modern Glassmorphism UI Design
- Smart Image Fallback System
- Responsive Design with Tailwind CSS
- Animated Transitions and Effects

---

## Dependencies

- **ox_lib** - Core library functions
- **ox_inventory** - Weapon image integration
- **QBox Framework** - Server framework

---

## Special Thanks

- **Ox Team** - For ox_lib and ox_inventory
- **QBox Team** - For the framework
- **FiveM Community** - For continued support and development

---

## License & Usage

This resource is developed by **Nexus-development** under the leadership of **MrRay**.

For support, updates, or custom development:
- Contact: **MrRay**
- Organization: **Nexus-development**

---

*© 2024 Nexus-development by MrRay. All rights reserved.*
