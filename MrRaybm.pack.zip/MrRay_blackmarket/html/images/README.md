# Weapon Images Guide

## Ox_Inventory Integration

This blackmarket NUI now uses **authentic GTA V weapon images** from ox_inventory! The system automatically loads the official game images for all weapons.

The system uses a **smart fallback hierarchy**:

1. **Primary**: ox_inventory images (authentic GTA V weapon images)
2. **Fallback 1**: Local custom images in `html/images/` folders
3. **Fallback 2**: SVG versions of custom images
4. **Final**: Placeholder image

### Automatic Image Loading
- All weapon images are automatically loaded from ox_inventory
- No manual setup required for standard GTA V weapons
- Images match exactly what players see in their inventory

### Supported Items
All standard GTA V weapons are supported, including:
- **Weapons**: WEAPON_PISTOL, WEAPON_ASSAULTRIFLE, WEAPON_SMG, etc.
- **Melee**: WEAPON_KNIFE, WEAPON_BAT, WEAPON_MACHETE, etc.
- **Ammo**: AMMO-9, AMMO-RIFLE, AMMO-SHOTGUN, etc.
- **Attachments**: AT_SCOPE_LARGE, AT_SUPPRESSOR, etc.

### Custom Images (Optional)
You can still add custom images for items not in ox_inventory:

#### Folder Structure
```
html/images/
├── weapons/        # Custom weapon images
├── melee/          # Custom melee images  
├── ammo/           # Custom ammo images
├── attachments/    # Custom attachment images
└── placeholder.svg # Fallback image
```

#### Adding Custom Images
1. Name the file exactly like the item spawn name
2. Place in the appropriate folder
3. The system will use ox_inventory first, then fall back to your custom image

### Sample Images Included
- `weapon_pistol.svg` - Basic pistol
- `weapon_assaultrifle.svg` - Assault rifle
- `weapon_knife.svg` - Combat knife  
- `ammo-9.svg` - 9mm ammunition

### Tips
- Use transparent backgrounds for best results
- Keep file sizes reasonable (under 500KB each)
- Test images by opening the blackmarket in-game
- Consider using consistent art style across all images

### Where to Find Images
- GTA V Wiki weapon pages
- FiveM community resources
- Create your own using image editing software
- Commission custom artwork

**Note**: Make sure to restart the resource after adding new images!
