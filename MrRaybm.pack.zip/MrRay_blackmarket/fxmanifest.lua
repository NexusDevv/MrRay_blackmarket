-- This file defines the resource for FiveM
-- Developed by Nexus-development by MrRay
fx_version 'cerulean'
game 'gta5'

author 'MrRay - Nexus-development'
description 'QBox Advanced Multi Functional Black Market NUI - Nexus-development'
version '1.0.0'

-- Dependencies
dependencies {
    'ox_lib',
    'ox_inventory'
}

-- QBox Convar
convar_level 'high'

-- NUI Page
-- Updated to point to your 'html/menu.html' file
ui_page 'html/menu.html'

-- Files to include
files {
    'html/menu.html',
    'html/images/**/*'
}

-- Shared scripts
shared_scripts {
    '@ox_lib/init.lua'
}

-- Client-side scripts
client_scripts {
    'config.lua',
    'client/client.lua'
}

-- Server-side scripts
server_scripts {
    'config.lua',
    'server/server.lua'
}


dependency '/assetpacks'